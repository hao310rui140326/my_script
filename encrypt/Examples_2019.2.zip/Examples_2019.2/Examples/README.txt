The examples included here are to be used with the Vivado encrypt command. 

For detailed usage of rights and encryption tool, please refer to "Encrypting IP in Vivado" in UG1118 - Creating and Packaging Custom IP. 

1. Example.v - This is the example verilog source code.

2. Example.vhd - This is the example VHDL source code.

3. Example+EmbeddedKeyfile.v - This is the example verilog source code along with keyfile inside it. 

4. Example+EmbeddedKeyfile.vhd - This is the example VHDL source code along with keyfile inside it.

5. keyfile_ver.txt - This is the file containing the Xilinx Key that is used to pass with the -key switch to Vivado encrypt command. It contains the Xilinx public key and encryption rights. Use it for encrypting Verilog sources. 

6. keyfile_vhd.txt - This is the file containing the Xilinx Key that is used to pass with the -key switch to Vivado encrypt command. It contains the Xilinx public key and encryption rights. Use it for encrypting VHDL sources. 

NOTE: When running the encrypt command it will overwrite the files, so please ensure you use -ext switch as shown below in example - it provides an extension to use for encrypted file. The original source file will be preserved if -ext is used with encrypt command. 

Example syntax for standalone keyfile:
% encrypt -key keyfile_ver.txt -ext .vp -lang verilog Example.v

Example syntax for embedded key file:
% encrypt -ext .vp -lang verilog Example+EmbeddedKeyfile.v
